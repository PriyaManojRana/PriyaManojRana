// JavaScript to handle button click event

document.getElementById('clickButton').addEventListener('click', function() {
    // Display a message when the button is clicked
    document.getElementById('message').innerHTML = "Hello, you clicked the button!";
});
